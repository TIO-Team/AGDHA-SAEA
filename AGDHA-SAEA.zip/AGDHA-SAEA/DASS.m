function candU = DASS( ...
    PopU, surrogateModel, cheapIdx, expensiveIdx, cheapEvaluator, ...
    n, nSearchPop, tmax, lb_all, ub_all, beta)

    nSearchPop = max(2, round(nSearchPop));
    tmax = max(1, round(tmax));
    nEach = max(1, ceil(nSearchPop/3));
    SurPopU = PopU;
    SurPopObj = surrogateEvaluateCandidates( ...
        SurPopU, cheapIdx, expensiveIdx, surrogateModel, lb_all, ub_all, cheapEvaluator);

    for t = 1 : tmax
        [SurFrontNo,~] = NDSort(SurPopObj, size(SurPopObj,1));
        SurCrowdDis    = CrowdingDistance(SurPopObj, SurFrontNo);
        [goodIdx, badIdx] = splitByCheapKMeans(SurPopObj, cheapIdx);

        SurOffU = generateDifficultyStateCandidates( ...
            SurPopU, SurPopObj, SurFrontNo, SurCrowdDis, goodIdx, badIdx, ...
            n, nEach, lb_all, ub_all, beta);
        SurOffObj = surrogateEvaluateCandidates( ...
            SurOffU, cheapIdx, expensiveIdx, surrogateModel, lb_all, ub_all, cheapEvaluator);

        [SurPopU, SurPopObj] = SurrogateEnvironmentalSelection( ...
            [SurPopU; SurOffU], [SurPopObj; SurOffObj], nSearchPop);
    end

    candU = SurPopU;
end

function Obj = surrogateEvaluateCandidates(U, cheapIdx, expensiveIdx, surrogateModel, lb_all, ub_all, cheapEvaluator)
    CheapObj = cheapEvaluator(U);
    FexpPred = PredictSurrogates(surrogateModel, U, lb_all, ub_all);

    nObj = max([cheapIdx, expensiveIdx]);
    Obj = zeros(size(U,1), nObj);
    Obj(:,cheapIdx) = CheapObj;
    Obj(:,expensiveIdx) = FexpPred;
    Obj = RepairObjectives(Obj);
end

function [goodIdx, badIdx] = splitByCheapKMeans(PopObj, cheapIdx)
    nPop = size(PopObj,1);
    if nPop <= 1
        goodIdx = (1:nPop)';
        badIdx  = (1:nPop)';
        return;
    end

    cheapIdx = cheapIdx(cheapIdx <= size(PopObj,2));
    if isempty(cheapIdx)
        cheapIdx = 1;
    end
    CheapObj = repairNonfiniteCheapObj(PopObj(:,cheapIdx));
    CheapObj = normalizeCheapObj(CheapObj);

    if size(unique(CheapObj,'rows'),1) < 2
        goodIdx = (1:nPop)';
        badIdx  = (1:nPop)';
        return;
    end

    [grp, centers] = kmeans(CheapObj, 2, ...
        'Replicates', 5, 'EmptyAction', 'singleton');
    ideal = min(CheapObj, [], 1);
    dist  = sqrt(sum((centers - ideal).^2, 2));
    [~, order] = sort(dist, 'ascend');

    goodIdx = find(grp == order(1));
    badIdx  = find(grp == order(end));
end

function candU = generateDifficultyStateCandidates( ...
    PopU, ~, FrontNo, CrowdDis, goodIdx, badIdx, ...
    n, nEach, lb_all, ub_all, beta)

    nTotal = 3*nEach;

    nPop = size(PopU,1);
    goodIdx = fallbackIndexSet(goodIdx, (1:nPop)', nPop);
    badIdx  = fallbackIndexSet(badIdx,  (1:nPop)', nPop);
    easyMask = estimateEasyMaskByStateContrast(PopU, goodIdx, badIdx, lb_all, ub_all);

    badU  = generateEasyMaskRepairCandidates(PopU, badIdx, goodIdx, easyMask, nEach, n, lb_all, ub_all);
    goodU = generateComplementGaussianCandidates(PopU, goodIdx, easyMask, nEach, n, lb_all, ub_all, beta);
    varyU = generateOrdinaryCandidates(PopU, FrontNo, CrowdDis, nEach, n, lb_all, ub_all);

    candU = [badU; goodU; varyU];
    if size(candU,1) > nTotal
        candU = candU(1:nTotal,:);
    end
end

function idx = fallbackIndexSet(idx, fallback, nPop)
    idx = unique(idx(:), 'stable');
    idx = idx(idx >= 1 & idx <= nPop);
    if isempty(idx)
        idx = unique(fallback(:), 'stable');
        idx = idx(idx >= 1 & idx <= nPop);
    end
    if isempty(idx)
        idx = (1:nPop)';
    end
end

function easyMask = estimateEasyMaskByStateContrast(PopU, goodIdx, badIdx, lb_all, ub_all)
    nVar = size(PopU,2);
    easyMask = zeros(1,nVar);
    easyMask(end) = 1;
    if numel(goodIdx) < 2 || numel(badIdx) < 2
        return;
    end

    Z = NormalizeParameters(PopU, lb_all, ub_all);
    goodZ = Z(goodIdx,:);
    badZ  = Z(badIdx,:);
    score = abs(mean(goodZ,1) - mean(badZ,1)) ./ ...
        (std(goodZ,0,1) + std(badZ,0,1) + 1e-12);
    score(~isfinite(score)) = 0;

    if any(score > 0)
        easyMask = otsuEasyMask(score);
        easyMask(end) = 1;
    end
end

function easyMask = otsuEasyMask(score)
    score = score(:)';
    nVar = numel(score);
    easyMask = zeros(1,nVar);

    score(~isfinite(score)) = 0;
    if nVar <= 0
        return;
    end
    if max(score) - min(score) <= 1e-12
        [~, best] = max(score);
        easyMask(best) = 1;
        return;
    end

    values = unique(score);
    thresholds = (values(1:end-1) + values(2:end)) / 2;
    bestCrit = -inf;
    bestTau  = thresholds(1);

    for i = 1 : numel(thresholds)
        tau = thresholds(i);
        low  = score < tau;
        high = score >= tau;
        if ~any(low) || ~any(high)
            continue;
        end

        wLow   = mean(low);
        wHigh  = mean(high);
        muLow  = mean(score(low));
        muHigh = mean(score(high));
        crit = wLow * wHigh * (muLow - muHigh)^2;
        if crit > bestCrit
            bestCrit = crit;
            bestTau  = tau;
        end
    end

    easyMask(score >= bestTau) = 1;
    if ~any(easyMask)
        [~, best] = max(score);
        easyMask(best) = 1;
    end
end

function badU = generateEasyMaskRepairCandidates(PopU, badIdx, goodIdx, easyMask, nCand, n, lb_all, ub_all)
    if nCand <= 0
        badU = zeros(0, size(PopU,2));
        return;
    end

    badIdx  = fallbackIndexSet(badIdx,  (1:size(PopU,1))', size(PopU,1));
    goodIdx = fallbackIndexSet(goodIdx, badIdx, size(PopU,1));

    pick  = badIdx(randi(numel(badIdx),  nCand, 1));
    teach = goodIdx(randi(numel(goodIdx), nCand, 1));
    parentU  = PopU(pick,:);
    teacherU = PopU(teach,:);

    alpha = 0.25 + 0.50*rand(nCand,1);
    mask  = repmat(easyMask, nCand, 1);
    badU  = parentU + repmat(alpha, 1, size(PopU,2)).*mask.*(teacherU - parentU);
    badU  = repairLatentBounds(badU, lb_all, ub_all, n);
end

function goodU = generateComplementGaussianCandidates(PopU, goodIdx, easyMask, nCand, n, lb_all, ub_all, beta)
    if nCand <= 0
        goodU = zeros(0, size(PopU,2));
        return;
    end

    goodIdx = fallbackIndexSet(goodIdx, (1:size(PopU,1))', size(PopU,1));
    pick    = goodIdx(randi(numel(goodIdx), nCand, 1));
    parentU = PopU(pick,:);

    compMask = 1 - easyMask;
    sigma = beta * (ub_all - lb_all) .* compMask;
    sigma(end) = 0;
    goodU = parentU + randn(size(parentU)).*repmat(sigma, nCand, 1);
    goodU = repairLatentBounds(goodU, lb_all, ub_all, n);
end

function U = repairLatentBounds(U, lb_all, ub_all, n)
    U = min(max(U, lb_all), ub_all);
    U(:,end) = max(0, min(n, round(U(:,end))));
end

function varyU = generateOrdinaryCandidates(PopU, FrontNo, CrowdDis, nCand, n, lb_all, ub_all)
    if nCand <= 0
        varyU = zeros(0, size(PopU,2));
        return;
    end

    parentCount = nCand + mod(nCand,2);
    parentCount = max(2, parentCount);
    pool = TournamentSelection(2, parentCount, FrontNo, -CrowdDis);
    parentU = PopU(pool,:);
    varyU = OperatorReal(parentU, lb_all, ub_all);
    varyU = varyU(1:min(nCand,size(varyU,1)),:);
    varyU(:,end) = max(0, min(n, round(varyU(:,end))));
end

function CheapObj = repairNonfiniteCheapObj(CheapObj)
    for j = 1 : size(CheapObj,2)
        col = CheapObj(:,j);
        finite = isfinite(col);
        if any(finite)
            fill = max(col(finite));
        else
            fill = 1;
        end
        col(~finite) = fill;
        CheapObj(:,j) = col;
    end
end

function CheapObj = normalizeCheapObj(CheapObj)
    lo = min(CheapObj, [], 1);
    hi = max(CheapObj, [], 1);
    range = hi - lo;
    range(range <= 1e-12) = 1;
    CheapObj = (CheapObj - lo) ./ range;
end

function [NextU, NextObj] = SurrogateEnvironmentalSelection(U, Obj, N)
    if size(U,1) <= N
        NextU   = U;
        NextObj = Obj;
        return;
    end

    SortObj = RepairObjectives(Obj);
    [FrontNo, MaxFNo] = NDSort(SortObj, N);
    selected = FrontNo < MaxFNo;
    Last     = find(FrontNo == MaxFNo);
    nLast    = N - nnz(selected);

    if nLast > 0
        CrowdDis = CrowdingDistance(SortObj, FrontNo);
        [~, rank] = sort(CrowdDis(Last), 'descend');
        take = min(nLast, numel(rank));
        selected(Last(rank(1:take))) = true;
    end

    NextU   = U(selected,:);
    NextObj = Obj(selected,:);
end

function OffspringDec = OperatorReal(Parent, lower, upper)
    Parent1      = Parent(1:floor(end/2),:);
    Parent2      = Parent(floor(end/2)+1:floor(end/2)*2,:);
    OffspringDec = GAreal(Parent1, Parent2, lower, upper, 1, 20, 1, 20);
end

function Offspring = GAreal(Parent1, Parent2, lower, upper, proC, disC, proM, disM)
    [N,D] = size(Parent1);
    beta  = zeros(N,D);
    mu    = rand(N,D);
    beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
    beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
    beta = beta.*(-1).^randi([0,1],N,D);
    beta(rand(N,D)<0.5) = 1;
    beta(repmat(rand(N,1)>proC,1,D)) = 1;
    Offspring = [(Parent1+Parent2)/2+beta.*(Parent1-Parent2)/2
                 (Parent1+Parent2)/2-beta.*(Parent1-Parent2)/2];

    Lower = repmat(lower,2*N,1);
    Upper = repmat(upper,2*N,1);
    Site  = rand(2*N,D) < proM/D;
    mu    = rand(2*N,D);
    temp = Site & mu<=0.5;
    Offspring       = min(max(Offspring,Lower),Upper);
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                      (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp = Site & mu>0.5;
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                      (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
end

function Z = NormalizeParameters(U, lb_all, ub_all)
    range = ub_all - lb_all;
    range(range == 0) = 1;
    Z = (U - lb_all) ./ range;
end

function Obj = RepairObjectives(Obj)
    Obj(~isfinite(Obj)) = inf;
end
