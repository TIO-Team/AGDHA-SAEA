function Sel = AGDSC(PopU, Instance, d)
    [N, ~] = size(PopU);
    [n, m] = size(Instance);
    Sel    = false(N,n);

    for i = 1 : N
        params = PopU(i,:);
        [scores, k] = decodeScores(params, Instance, d, n, m);

        [~, idx] = maxk(scores, k);
        sel      = false(n,1);
        sel(idx) = true;
        Sel(i,:) = sel';
    end
end

function [scores, k] = decodeScores(params, Instance, d, n, m)
    ptr = 1;
    W_Q    = reshape(params(ptr:ptr+m*d-1), m, d); ptr = ptr + m*d;
    W_K    = reshape(params(ptr:ptr+m*d-1), m, d); ptr = ptr + m*d;
    W_V    = reshape(params(ptr:ptr+m*d-1), m, d); ptr = ptr + m*d;

    Q      = Instance*W_Q;
    K      = Instance*W_K;
    V      = Instance*W_V;
    att    = rowSoftmax(Q*K' / sqrt(d));
    F      = att*V;
    F_res  = F + V;
    scores = F_res;
    k = max(0, min(n, round(params(ptr))));
end

function y = rowSoftmax(x)
    x = x - max(x,[],2);
    ex = exp(x);
    y = ex ./ max(sum(ex,2), realmin);
end
