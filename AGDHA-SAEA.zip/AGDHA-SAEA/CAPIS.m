function selected = CAPIS(CandCheapObj, FexpPred, ArcObj, cheapIdx, expensiveIdx, L)
    nCand = size(CandCheapObj,1);
    if nCand <= 0
        selected = 1;
        return;
    end

    if isempty(ArcObj)
        selected = 1;
        return;
    end

    nObj = size(ArcObj,2);
    cheapIdx = cheapIdx(cheapIdx >= 1 & cheapIdx <= nObj);
    expensiveIdx = expensiveIdx(expensiveIdx >= 1 & expensiveIdx <= nObj);
    if isempty(cheapIdx) || size(CandCheapObj,2) ~= numel(cheapIdx)
        selected = 1;
        return;
    end
    if isempty(expensiveIdx) || size(FexpPred,2) ~= numel(expensiveIdx)
        selected = 1;
        return;
    end

    CandCheapObj = RepairObjectives(CandCheapObj);
    FexpPred = RepairObjectives(FexpPred);
    ArcObj = RepairObjectives(ArcObj);

    ArcCheapObj = ArcObj(:,cheapIdx);
    cheapProb = cheapDominanceProbability(CandCheapObj, ArcCheapObj);
    cheapPool = find(rand(nCand,1) <= cheapProb);
    if isempty(cheapPool)
        [~, cheapPool] = max(cheapProb);
    end

    validMask = true(numel(cheapPool),1);
    tol = 1e-12;
    nDominators = zeros(numel(cheapPool),1);
    for i = 1 : numel(cheapPool)
        idx = cheapPool(i);
        candObj = zeros(1,nObj);
        candObj(cheapIdx) = CandCheapObj(idx,:);
        candObj(expensiveIdx) = FexpPred(idx,:);
        dominatedBy = all(ArcObj <= candObj + tol, 2) & any(ArcObj < candObj - tol, 2);
        nDominators(i) = sum(dominatedBy);
        validMask(i) = nDominators(i) == 0;
    end

    validPool = cheapPool(validMask);
    if isempty(validPool)
        validPool = cheapPool(nDominators == min(nDominators));
    end
    sparsity = cheapKNNSparsity(CandCheapObj(validPool,:), ArcCheapObj, L);
    selected = chooseMaxSparsityStable(sparsity, validPool);
end

function pKeep = cheapDominanceProbability(CandCheapObj, ArcCheapObj)
    CandCheapObj = RepairObjectives(CandCheapObj);
    ArcCheapObj = RepairObjectives(ArcCheapObj);
    nCand = size(CandCheapObj,1);
    pKeep = 0.5 * ones(nCand,1);
    if isempty(ArcCheapObj)
        return;
    end

    tol = 1e-12;
    for i = 1 : nCand
        obj = CandCheapObj(i,:);
        dPlus = sum(all(obj <= ArcCheapObj + tol, 2) & any(obj < ArcCheapObj - tol, 2));
        dMinus = sum(all(ArcCheapObj <= obj + tol, 2) & any(ArcCheapObj < obj - tol, 2));
        pKeep(i) = (dPlus + 1) / (dPlus + dMinus + 2);
    end
end

function sparsity = cheapKNNSparsity(CandCheap, ArcCheap, k)
    [CandN, ArcN] = normalizeCheapSpace(CandCheap, ArcCheap);
    D = pdist2(CandN, ArcN);
    if isempty(D)
        sparsity = zeros(size(CandCheap,1),1);
        return;
    end
    k = min(k, size(D,2));
    D = sort(D, 2, 'ascend');
    sparsity = mean(D(:,1:k), 2);
end

function selected = chooseMaxSparsityStable(sparsity, idx)
    sparsity = sparsity(:);
    idx = idx(:);
    sparsity(~isfinite(sparsity)) = -inf;
    [~, order] = sortrows([-sparsity, idx]);
    selected = idx(order(1));
end

function [CandN, ArcN] = normalizeCheapSpace(CandCheap, ArcCheap)
    AllCheap = [CandCheap; ArcCheap];
    lo = min(AllCheap, [], 1);
    hi = max(AllCheap, [], 1);
    range = hi - lo;
    range(range <= 1e-12) = 1;
    CandN = (CandCheap - lo) ./ range;
    ArcN  = (ArcCheap  - lo) ./ range;
end

function Obj = RepairObjectives(Obj)
    Obj(~isfinite(Obj)) = inf;
end
