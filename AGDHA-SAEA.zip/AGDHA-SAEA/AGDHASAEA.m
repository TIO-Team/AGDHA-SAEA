classdef AGDHASAEA < ALGORITHM
% <multi> <binary> <large/none> <sparse/none> <expensive/none>
% cheapIdx --- 1 --- Indices of the cheap/easy objective set
% tmax --- 30 --- Number of surrogate-search generations per expensive infill iteration
% L --- 5 --- Number of nearest archive points used by cheap-space sparsity

    methods
        function main(Algo, Problem)

            [cheapIdxSpec, beta, tmax, L] = Algo.ParameterSet(1, 0.05, 30, 5);
            lb        = -1;
            ub        = 1;
            L = round(L);
            Instance = ExtractFeatures(Problem);
            [n, m]   = size(Instance);
            d = 1;

            [PopU, lb_all, ub_all] = InitializeParameters(m, d, lb, ub, n, Problem.N);

            nSearchPop      = Problem.N;
            [cheapIdx, expensiveIdx] = ResolveObjectives(Problem, cheapIdxSpec);
            cheapEvaluator = @(U)EvaluateCheapObjectives( ...
                U, Problem, Instance, d, cheapIdx);

            Sel  = AGDSC(PopU, Instance, d);
            Pop  = Problem.Evaluation(Sel);
            Arc  = Pop;
            ArcU = PopU;

            surrogateModel = TrainSurrogates(ArcU, Arc.objs, expensiveIdx, lb_all, ub_all);

            while Algo.NotTerminated(Arc)

                candU = DASS( ...
                    PopU, surrogateModel, cheapIdx, expensiveIdx, cheapEvaluator, ...
                    n, nSearchPop, tmax, lb_all, ub_all, beta);

                candCheapObj = cheapEvaluator(candU);
                fexp_pred    = PredictSurrogates(surrogateModel, candU, lb_all, ub_all);
                selected = CAPIS( ...
                    candCheapObj, fexp_pred, Arc.objs, cheapIdx, expensiveIdx, L);
                selectU  = candU(selected,:);

                Sel = AGDSC(selectU, Instance, d);
                Off = Problem.Evaluation(Sel);

                Arc  = [Arc, Off];
                ArcU = [ArcU; selectU];

                [Pop, PopU] = EnvironmentalSelection( ...
                    [Pop,Off], [PopU; selectU], Problem.N);

                surrogateModel = TrainSurrogates(ArcU, Arc.objs, expensiveIdx, lb_all, ub_all);
            end
        end
    end
end

function [PopU, lb_all, ub_all] = InitializeParameters(m, d, lb, ub, n, PopSize)
    Dparam = 3*m*d + 1;
    lb_all = [repmat(lb,1,Dparam-1), 0];
    ub_all = [repmat(ub,1,Dparam-1), n];
    PopU   = repmat(lb_all, PopSize, 1) + rand(PopSize, Dparam).*repmat(ub_all-lb_all, PopSize, 1);
end

function [cheapIdx, expensiveIdx] = ResolveObjectives(Problem, cheapIdxSpec)
    allIdx = 1 : Problem.M;
    cheapIdx = double(cheapIdxSpec(:)');
    cheapIdx = unique(cheapIdx, 'stable');
    expensiveIdx = setdiff(allIdx, cheapIdx, 'stable');
end

function [Population, U] = EnvironmentalSelection(Population, U, N)
    if numel(Population) <= N
        return;
    end

    SortObj = RepairObjectives(Population.objs);
    [FrontNo, MaxFNo] = NDSort(SortObj, Population.cons, N);
    selected = FrontNo < MaxFNo;
    Last     = find(FrontNo == MaxFNo);
    nLast    = N - nnz(selected);

    if nLast > 0
        CrowdDis = CrowdingDistance(SortObj, FrontNo);
        [~, rank] = sort(CrowdDis(Last), 'descend');
        take = min(nLast, numel(rank));
        selected(Last(rank(1:take))) = true;
    end

    Population = Population(selected);
    U          = U(selected,:);
end

function Obj = RepairObjectives(Obj)
    Obj(~isfinite(Obj)) = inf;
end
