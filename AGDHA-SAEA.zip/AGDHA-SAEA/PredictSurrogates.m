function Fexp = PredictSurrogates(model, candU, lb_all, ub_all)
    Z    = NormalizeParameters(candU, lb_all, ub_all);
    Fexp = zeros(size(candU,1), numel(model.rbf));
    for i = 1 : numel(model.rbf)
        Fexp(:,i) = predictRBF(model.rbf{i}, Z);
    end
end

function mu = predictRBF(model, Ztest)
    Dtest = pdist2(Ztest, model.Ztrain);
    Phi   = exp(-Dtest.^2/(2*model.sigma^2));
    mu    = Phi * model.w;
end

function Z = NormalizeParameters(U, lb_all, ub_all)
    range = ub_all - lb_all;
    range(range == 0) = 1;
    Z = (U - lb_all) ./ range;
end
