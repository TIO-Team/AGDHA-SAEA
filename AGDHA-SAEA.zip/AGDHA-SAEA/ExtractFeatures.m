function X = ExtractFeatures(Problem)
    switch class(Problem)
        case 'Sparse_IS'
            X = extractIS(Problem);
            X = normrnd(X,0.1);
        case 'Sparse_CN'
            A = sparse(double(Problem.A));
            X = extractGraphFeatures(A);
        case 'MOFS'
            X = extractMOFS(Problem);
        otherwise
            if ismethod(Problem,'GetVariableFeatures')
                X = Problem.GetVariableFeatures();
            else
                error(['AGDHASAEA future problems must implement GetVariableFeatures() ', ...
                       'to return one feature row per binary decision variable.']);
            end
    end
    X = double(X);
    if size(X,1) ~= Problem.D
        error('AGDHASAEA variable feature matrix must contain Problem.D rows.');
    end
end

function X = extractIS(Problem)
    Data   = full(Problem.Data);
    X0     = Data(:,1:end-1);
    labels = Data(:,end);

    mu = mean(X0,1);
    sd = std(X0,[],1) + 1e-8;
    Xs = (X0 - mu) ./ sd;

    X2    = Xs.^2;
    eps0  = 1e-3;
    Xinv  = 1 ./ (abs(Xs) + eps0);
    Xsqrt = sqrt(abs(Xs));

    X = [Xs, X2, Xinv, Xsqrt];

    mu = mean(X,1);
    sd = std(X,[],1) + 1e-8;
    X  = (X - mu) ./ sd;
    X  = [X, labels];
end

function X = extractGraphFeatures(A)
    n   = size(A,1);
    deg = full(sum(A,2));
    tri = diag(A^3)/2;
    cc  = zeros(n,1);
    for i = 1 : n
        if deg(i) > 1
            cc(i) = tri(i)/(deg(i)*(deg(i)-1)/2);
        end
    end

    opts.disp = 0;
    [v,~]     = eigs(A,1,'largestreal',opts);
    ec        = abs(v);
    d_pr      = 0.85;
    tol       = 1e-6;
    pr        = ones(n,1)/n;
    Mpr       = A./sum(A,2);
    for it = 1 : 100
        prn = (1-d_pr)/n + d_pr*(Mpr' * pr);
        if norm(prn-pr,1) < tol
            break;
        end
        pr = prn;
    end
    X = [deg,cc,ec,pr];

    mu = mean(X,1);
    sd = std(X,[],1) + 1e-8;
    X  = (X - mu) ./ sd;
end

function X = extractMOFS(Problem)
    Data   = double(Problem.TrainX);
    Labels = Problem.TrainY(:);
    Data   = cleanMOFSData(Data);

    meanX   = mean(Data, 1);
    stdX    = std(Data, 0, 1);
    fisherX = computeMOFSFisherScore(Data, Labels);

    nBins = min(10, max(3, round(sqrt(max(size(Data,1),1)))));
    [binIdx, binProb, entropyX] = discretizeMOFSFeatures(Data, nBins);
    miX = computeMOFSMutualInfo(binIdx, binProb, entropyX, Labels, nBins);

    X = [meanX(:), stdX(:), fisherX(:), miX(:)];
    X = standardizeMOFSFeatureMatrix(X);
end

function Data = cleanMOFSData(Data)
    if isempty(Data)
        return;
    end
    finiteMask = isfinite(Data);
    for j = 1 : size(Data,2)
        valid = finiteMask(:,j);
        if all(valid)
            continue;
        end
        if any(valid)
            fillValue = median(Data(valid,j));
        else
            fillValue = 0;
        end
        Data(~valid,j) = fillValue;
    end
end

function [binIdx, binProb, entropyX] = discretizeMOFSFeatures(Data, nBins)
    eps0 = 1e-12;
    [n, D] = size(Data);
    binIdx = ones(n, D, 'uint16');
    if n <= 0 || D <= 0
        binProb  = zeros(nBins, D);
        entropyX = zeros(1, D);
        return;
    end
    lo    = min(Data, [], 1);
    hi    = max(Data, [], 1);
    range = hi - lo;
    for j = 1 : D
        if range(j) <= eps0
            continue;
        end
        bj = floor((Data(:,j) - lo(j)) ./ (range(j) + eps0) * nBins) + 1;
        bj(bj < 1)     = 1;
        bj(bj > nBins) = nBins;
        binIdx(:,j)    = uint16(bj);
    end
    binProb = zeros(nBins, D);
    for b = 1 : nBins
        binProb(b,:) = mean(binIdx == b, 1);
    end
    entropyX = -sum(binProb .* log(binProb + eps0), 1);
end

function miX = computeMOFSMutualInfo(binIdx, binProb, entropyX, Labels, nBins)
    eps0 = 1e-12;
    n    = size(binIdx,1);
    D    = size(binIdx,2);
    miX  = zeros(1, D);
    if isempty(Labels) || numel(Labels) ~= n || D <= 0
        return;
    end
    [~,~,labelIdx] = unique(Labels(:));
    nClass = max(labelIdx);
    if isempty(nClass) || nClass < 2
        return;
    end
    classCount  = accumarray(labelIdx, 1, [nClass, 1]);
    classProb   = classCount / max(n,1);
    labelEntropy = -sum(classProb .* log(classProb + eps0));
    for c = 1 : nClass
        mask = labelIdx == c;
        pc   = classProb(c);
        if pc <= 0
            continue;
        end
        for b = 1 : nBins
            joint = sum(binIdx(mask,:) == b, 1) / max(n,1);
            valid = joint > 0;
            if any(valid)
                miX(valid) = miX(valid) + joint(valid) .* ...
                    log(joint(valid) ./ (binProb(b,valid) * pc + eps0));
            end
        end
    end
    miX = 2 * miX ./ (entropyX + labelEntropy + eps0);
    miX(~isfinite(miX)) = 0;
end

function fisherX = computeMOFSFisherScore(Data, Labels)
    [n, D] = size(Data);
    fisherX = zeros(1, D);
    if isempty(Labels) || numel(Labels) ~= n || D <= 0
        return;
    end
    [~,~,labelIdx] = unique(Labels(:));
    nClass = max(labelIdx);
    if isempty(nClass) || nClass < 2
        return;
    end
    globalMean = mean(Data, 1);
    numerator  = zeros(1, D);
    denominator = zeros(1, D);
    for c = 1 : nClass
        mask = labelIdx == c;
        nc   = sum(mask);
        if nc <= 0
            continue;
        end
        classData = Data(mask,:);
        classMean = mean(classData, 1);
        classVar  = mean(bsxfun(@minus, classData, classMean).^2, 1);
        numerator   = numerator + nc * (classMean - globalMean).^2;
        denominator = denominator + nc * classVar;
    end
    fisherX = numerator ./ (denominator + 1e-12);
    fisherX(~isfinite(fisherX)) = 0;
end

function X = standardizeMOFSFeatureMatrix(X)
    X(~isfinite(X)) = 0;
    if isempty(X)
        return;
    end
    mu = mean(X, 1);
    sd = std(X, 0, 1);
    sd(sd < 1e-8) = 1;
    X = bsxfun(@rdivide, bsxfun(@minus, X, mu), sd);
    X(~isfinite(X)) = 0;
end
