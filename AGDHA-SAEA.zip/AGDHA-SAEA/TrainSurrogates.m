function model = TrainSurrogates(U, Obj, expensiveIdx, lb_all, ub_all)
    Z = NormalizeParameters(U, lb_all, ub_all);

    expensiveIdx = expensiveIdx(expensiveIdx >= 1 & expensiveIdx <= size(Obj,2));
    if isempty(expensiveIdx)
        expensiveIdx = size(Obj,2);
    end
    model.expensiveIdx = expensiveIdx;
    model.rbf = cell(1, numel(expensiveIdx));
    for i = 1 : numel(expensiveIdx)
        model.rbf{i} = trainRBF(Z, Obj(:,expensiveIdx(i)));
    end
end

function model = trainRBF(Z, y)
    y          = y(:);
    Dmat       = pdist2(Z, Z);
    sigmaData  = Dmat(Dmat > 0);
    if isempty(sigmaData)
        sigma = 1;
    else
        sigma = mean(sigmaData) + 1e-6;
    end
    Phi = exp(-Dmat.^2/(2*sigma^2));

    lambda = 1e-6;
    w      = (Phi + lambda*eye(size(Phi))) \ y;

    model.sigma  = sigma;
    model.Ztrain = Z;
    model.w      = w;
end

function Z = NormalizeParameters(U, lb_all, ub_all)
    range = ub_all - lb_all;
    range(range == 0) = 1;
    Z = (U - lb_all) ./ range;
end
