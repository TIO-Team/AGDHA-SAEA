function CheapObj = EvaluateCheapObjectives(PopU, Problem, Instance, d, cheapIdx)
    ratioProblems = {'Sparse_IS','Sparse_CN','MOFS'};
    if isequal(cheapIdx,1) && any(strcmp(class(Problem),ratioProblems))
        n = Problem.D;
        k = max(0,min(n,round(PopU(:,end))));
        CheapObj = k/max(n,1);
        return;
    end

    if ~ismethod(Problem,'CalCheapObj')
        error('AGDHASAEA:CheapObjectiveDefinitionRequired', ...
            ['Define the exact cheap objectives for %s in EvaluateCheapObjectives.m, ', ...
             'or implement CalCheapObj(PopDec,cheapIdx) for decoded binary solutions.'], ...
            class(Problem));
    end

    PopDec = AGDSC(PopU,Instance,d);
    CheapObj = Problem.CalCheapObj(PopDec,cheapIdx);
    if size(CheapObj,1)~=size(PopU,1) || size(CheapObj,2)~=numel(cheapIdx)
        error('AGDHASAEA:CheapObjectiveSize', ...
            'CalCheapObj must return one row per candidate and one column per cheapIdx entry.');
    end
end
